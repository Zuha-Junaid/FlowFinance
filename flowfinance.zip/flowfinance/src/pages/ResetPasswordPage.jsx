import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Loader2, CheckCircle2, Eye, EyeOff } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import AuthCard from '../components/AuthCard'

export default function ResetPasswordPage() {
  const { resetPassword } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ email: '', password: '', confirm: '' })
  const [showPwd, setShowPwd] = useState(false)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [done, setDone] = useState(false)

  const handle = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }))

  const submit = async e => {
    e.preventDefault()
    setError('')
    if (form.password !== form.confirm) { setError('Passwords do not match.'); return }
    if (form.password.length < 6) { setError('Password must be at least 6 characters.'); return }
    setLoading(true)
    await new Promise(r => setTimeout(r, 500))
    const res = resetPassword(form.email, form.password)
    setLoading(false)
    if (res.error) setError(res.error)
    else { setDone(true); setTimeout(() => navigate('/login'), 2000) }
  }

  return (
    <AuthCard title="Set new password" subtitle="Choose a strong new password for your account">
      {done ? (
        <div className="text-center py-4">
          <CheckCircle2 size={40} className="text-primary-500 mx-auto mb-3" />
          <p className="font-semibold text-slate-800">Password updated!</p>
          <p className="text-sm text-slate-500 mt-1">Redirecting you to login…</p>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          {error && (
            <div className="text-sm text-rose-600 bg-rose-50 border border-rose-100 rounded-xl px-4 py-2.5">
              {error}
            </div>
          )}
          <div>
            <label className="label">Email address</label>
            <input name="email" type="email" required className="input" placeholder="you@example.com"
              value={form.email} onChange={handle} />
          </div>
          <div>
            <label className="label">New password</label>
            <div className="relative">
              <input name="password" type={showPwd ? 'text' : 'password'} required
                className="input pr-10" placeholder="At least 6 characters"
                value={form.password} onChange={handle} />
              <button type="button" onClick={() => setShowPwd(v => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>
          <div>
            <label className="label">Confirm new password</label>
            <input name="confirm" type="password" required className="input" placeholder="••••••••"
              value={form.confirm} onChange={handle} />
          </div>
          <button type="submit" className="btn-primary w-full flex items-center justify-center gap-2" disabled={loading}>
            {loading && <Loader2 size={15} className="animate-spin" />}
            Reset password
          </button>
        </form>
      )}
      <p className="mt-5 text-center text-sm text-slate-500">
        <Link to="/login" className="text-primary-600 font-semibold hover:underline">← Back to login</Link>
      </p>
    </AuthCard>
  )
}
