import React, { useMemo, useState } from 'react'
import { TrendingUp, TrendingDown, Wallet, Plus, ArrowRight, Download, Loader2 } from 'lucide-react'
import { Link } from 'react-router-dom'
import {
  AreaChart, Area, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts'
import { useAuth } from '../context/AuthContext'
import { useTransactions } from '../context/TransactionContext'
import StatCard from '../components/StatCard'
import TransactionModal from '../components/TransactionModal'
import { generateFinancialReport } from '../utils/generateReport'
import { format, parseISO, eachMonthOfInterval, subMonths } from 'date-fns'

const COLORS = ['#22c55e','#3b82f6','#f59e0b','#ef4444','#8b5cf6','#ec4899']
const fmt = (v) => `$${v.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-white border border-surface-200 rounded-xl shadow-card p-3 text-sm">
      <p className="font-semibold text-slate-700 mb-1">{label}</p>
      {payload.map(p => (
        <p key={p.name} style={{ color: p.color }} className="font-medium">
          {p.name}: {fmt(p.value)}
        </p>
      ))}
    </div>
  )
}

export default function DashboardPage() {
  const { user } = useAuth()
  const { transactions, totalIncome, totalExpense, balance } = useTransactions()
  const [modalOpen, setModalOpen] = useState(false)
  const [downloading, setDownloading] = useState(false)

  const handleDownloadReport = async () => {
    setDownloading(true)
    // Small delay so spinner renders before heavy PDF work
    await new Promise(r => setTimeout(r, 100))
    try {
      generateFinancialReport(transactions, user)
    } catch (e) {
      console.error('PDF generation failed', e)
    }
    setDownloading(false)
  }

  const monthlyData = useMemo(() => {
    const now = new Date()
    return eachMonthOfInterval({ start: subMonths(now, 5), end: now }).map(m => {
      const key = format(m, 'yyyy-MM')
      const f = transactions.filter(t => t.date.startsWith(key))
      return {
        month:   format(m, 'MMM'),
        income:  f.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0),
        expense: f.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0),
      }
    })
  }, [transactions])

  const categoryData = useMemo(() => {
    const map = {}
    transactions.filter(t => t.type === 'expense').forEach(t => {
      map[t.category] = (map[t.category] || 0) + t.amount
    })
    return Object.entries(map)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 6)
  }, [transactions])

  const recent = transactions.slice(0, 5)
  const greeting = new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 18 ? 'afternoon' : 'evening'

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900">
            Good {greeting}, {user?.name?.split(' ')[0]} 👋
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">Here's your financial overview</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleDownloadReport}
            disabled={downloading || transactions.length === 0}
            className="flex items-center gap-2 bg-white border border-surface-200 hover:bg-surface-50
                       text-slate-700 font-semibold text-sm px-4 py-2.5 rounded-xl shadow-card
                       transition-colors duration-150 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {downloading
              ? <Loader2 size={15} className="animate-spin text-primary-600" />
              : <Download size={15} className="text-primary-600" />
            }
            {downloading ? 'Generating…' : 'Download Report'}
          </button>
          <button onClick={() => setModalOpen(true)} className="btn-primary flex items-center gap-2">
            <Plus size={15} strokeWidth={2.5} />
            Add Transaction
          </button>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard label="Total Balance"  amount={balance}      variant="balance"  icon={Wallet}       subtitle="Net income - expenses" />
        <StatCard label="Total Income"   amount={totalIncome}  variant="income"   icon={TrendingUp}   subtitle="All time income" />
        <StatCard label="Total Expenses" amount={totalExpense} variant="expense"  icon={TrendingDown} subtitle="All time spending" />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="card lg:col-span-2">
          <h2 className="font-semibold text-slate-800 mb-4">Monthly Overview</h2>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={monthlyData} margin={{ top: 5, right: 5, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="gI" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#22c55e" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gE" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#f43f5e" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#f43f5e" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} tickFormatter={fmt} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Legend iconType="circle" iconSize={8}
                formatter={v => <span className="text-xs text-slate-600 capitalize">{v}</span>} />
              <Area type="monotone" dataKey="income"  stroke="#22c55e" strokeWidth={2} fill="url(#gI)" name="Income" />
              <Area type="monotone" dataKey="expense" stroke="#f43f5e" strokeWidth={2} fill="url(#gE)" name="Expenses" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h2 className="font-semibold text-slate-800 mb-4">Spending by Category</h2>
          {categoryData.length === 0 ? (
            <p className="text-sm text-slate-400 text-center py-10">No expense data</p>
          ) : (
            <>
              <ResponsiveContainer width="100%" height={160}>
                <PieChart>
                  <Pie data={categoryData} cx="50%" cy="50%" innerRadius={45} outerRadius={72}
                    dataKey="value" paddingAngle={3}>
                    {categoryData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={v => fmt(v)} />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-1.5 mt-2">
                {categoryData.slice(0, 4).map((c, i) => (
                  <div key={c.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ background: COLORS[i % COLORS.length] }} />
                      <span className="text-slate-600">{c.name}</span>
                    </div>
                    <span className="font-medium text-slate-700">{fmt(c.value)}</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Recent transactions */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-slate-800">Recent Transactions</h2>
          <Link to="/transactions" className="text-sm text-primary-600 font-medium hover:underline flex items-center gap-1">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        {recent.length === 0 ? (
          <p className="text-sm text-slate-400 py-6 text-center">No transactions yet. Add your first one!</p>
        ) : (
          <div className="divide-y divide-surface-100">
            {recent.map(t => (
              <div key={t.id} className="flex items-center gap-4 py-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0
                  ${t.type === 'income' ? 'bg-green-50' : 'bg-rose-50'}`}>
                  {t.type === 'income'
                    ? <TrendingUp size={15} className="text-green-600" />
                    : <TrendingDown size={15} className="text-rose-500" />
                  }
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-800 truncate">{t.description}</p>
                  <p className="text-xs text-slate-400">{t.category} · {format(parseISO(t.date), 'MMM d, yyyy')}</p>
                </div>
                <span className={`text-sm font-bold ${t.type === 'income' ? 'text-green-600' : 'text-rose-500'}`}>
                  {t.type === 'income' ? '+' : '-'}${t.amount.toFixed(2)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      <TransactionModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </div>
  )
}
