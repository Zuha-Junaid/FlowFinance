import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Eye, EyeOff, Loader2 } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import AuthCard from '../components/AuthCard'

export default function RegisterPage() {
  const { register } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' })
  const [showPwd, setShowPwd] = useState(false)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handle = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }))

  const submit = async e => {
    e.preventDefault()
    setError('')
    if (form.password !== form.confirm) { setError('Passwords do not match.'); return }
    if (form.password.length < 6) { setError('Password must be at least 6 characters.'); return }
    setLoading(true)
    await new Promise(r => setTimeout(r, 400))
    const res = register(form)
    setLoading(false)
    if (res.error) setError(res.error)
    else navigate('/')
  }

  return (
    <AuthCard title="Create your account" subtitle="Start tracking your finances today — it's free">
      <form onSubmit={submit} className="space-y-4">
        {error && (
          <div className="text-sm text-rose-600 bg-rose-50 border border-rose-100 rounded-xl px-4 py-2.5">
            {error}
          </div>
        )}

        <div>
          <label className="label">Full name</label>
          <input name="name" type="text" required className="input" placeholder="John Doe"
            value={form.name} onChange={handle} />
        </div>

        <div>
          <label className="label">Email address</label>
          <input name="email" type="email" required autoComplete="email"
            className="input" placeholder="you@example.com"
            value={form.email} onChange={handle} />
        </div>

        <div>
          <label className="label">Password</label>
          <div className="relative">
            <input name="password" type={showPwd ? 'text' : 'password'} required
              className="input pr-10" placeholder="At least 6 characters"
              value={form.password} onChange={handle} />
            <button type="button" onClick={() => setShowPwd(v => !v)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
              {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
        </div>

        <div>
          <label className="label">Confirm password</label>
          <input name="confirm" type="password" required className="input" placeholder="••••••••"
            value={form.confirm} onChange={handle} />
        </div>

        <button type="submit" className="btn-primary w-full flex items-center justify-center gap-2" disabled={loading}>
          {loading && <Loader2 size={15} className="animate-spin" />}
          Create account
        </button>
      </form>

      <p className="mt-5 text-center text-sm text-slate-500">
        Already have an account?{' '}
        <Link to="/login" className="text-primary-600 font-semibold hover:underline">Sign in</Link>
      </p>
    </AuthCard>
  )
}
