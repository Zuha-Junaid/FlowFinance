import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { Loader2, CheckCircle2 } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import AuthCard from '../components/AuthCard'

export default function ForgotPasswordPage() {
  const { forgotPassword } = useAuth()
  const [email, setEmail] = useState('')
  const [status, setStatus] = useState(null) // null | 'success' | 'error'
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const submit = async e => {
    e.preventDefault()
    setError(''); setStatus(null)
    setLoading(true)
    await new Promise(r => setTimeout(r, 500))
    const res = forgotPassword(email)
    setLoading(false)
    if (res.error) setError(res.error)
    else setStatus('success')
  }

  return (
    <AuthCard title="Reset your password" subtitle="Enter your email and we'll send a reset link">
      {status === 'success' ? (
        <div className="text-center py-4">
          <CheckCircle2 size={40} className="text-primary-500 mx-auto mb-3" />
          <p className="font-semibold text-slate-800">Check your email</p>
          <p className="text-sm text-slate-500 mt-1 mb-5">
            We sent a password reset link to <span className="font-medium">{email}</span>
          </p>
          <Link to="/reset-password" className="btn-primary inline-block">
            Enter reset code →
          </Link>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          {error && (
            <div className="text-sm text-rose-600 bg-rose-50 border border-rose-100 rounded-xl px-4 py-2.5">
              {error}
            </div>
          )}
          <div>
            <label className="label">Email address</label>
            <input type="email" required className="input" placeholder="you@example.com"
              value={email} onChange={e => setEmail(e.target.value)} />
          </div>
          <button type="submit" className="btn-primary w-full flex items-center justify-center gap-2" disabled={loading}>
            {loading && <Loader2 size={15} className="animate-spin" />}
            Send reset link
          </button>
        </form>
      )}
      <p className="mt-5 text-center text-sm text-slate-500">
        <Link to="/login" className="text-primary-600 font-semibold hover:underline">← Back to login</Link>
      </p>
    </AuthCard>
  )
}
