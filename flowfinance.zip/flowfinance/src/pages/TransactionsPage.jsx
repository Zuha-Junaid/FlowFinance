import React, { useState, useMemo } from 'react'
import { Plus, Search, Filter, TrendingUp, TrendingDown, Pencil, Trash2, ChevronDown } from 'lucide-react'
import { format, parseISO } from 'date-fns'
import { useTransactions } from '../context/TransactionContext'
import TransactionModal from '../components/TransactionModal'

const TYPES = ['all', 'income', 'expense']
const SORTS = [
  { label: 'Date (newest)', value: 'date-desc' },
  { label: 'Date (oldest)', value: 'date-asc' },
  { label: 'Amount (high)', value: 'amount-desc' },
  { label: 'Amount (low)',  value: 'amount-asc' },
]

export default function TransactionsPage() {
  const { transactions, deleteTransaction, totalIncome, totalExpense } = useTransactions()
  const [modalOpen, setModalOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState('all')
  const [sort, setSort] = useState('date-desc')
  const [deleteId, setDeleteId] = useState(null)

  const filtered = useMemo(() => {
    let list = [...transactions]
    if (typeFilter !== 'all') list = list.filter(t => t.type === typeFilter)
    if (search.trim()) {
      const q = search.toLowerCase()
      list = list.filter(t =>
        t.description.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q)
      )
    }
    const [field, dir] = sort.split('-')
    list.sort((a, b) => {
      const va = field === 'date' ? a.date : a.amount
      const vb = field === 'date' ? b.date : b.amount
      return dir === 'asc' ? (va > vb ? 1 : -1) : (va < vb ? 1 : -1)
    })
    return list
  }, [transactions, typeFilter, search, sort])

  const handleEdit = (t) => { setEditing(t); setModalOpen(true) }
  const handleAdd  = ()  => { setEditing(null); setModalOpen(true) }
  const confirmDelete = (id) => { deleteTransaction(id); setDeleteId(null) }

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Transactions</h1>
          <p className="text-sm text-slate-500 mt-0.5">{transactions.length} total transactions</p>
        </div>
        <button onClick={handleAdd} className="btn-primary flex items-center gap-2">
          <Plus size={15} strokeWidth={2.5} />
          Add Transaction
        </button>
      </div>

      {/* Summary row */}
      <div className="grid grid-cols-2 gap-4">
        <div className="card flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-green-50 flex items-center justify-center">
            <TrendingUp size={18} className="text-green-600" />
          </div>
          <div>
            <p className="text-xs text-slate-400 font-medium">Total Income</p>
            <p className="text-lg font-bold text-green-600">${totalIncome.toFixed(2)}</p>
          </div>
        </div>
        <div className="card flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-rose-50 flex items-center justify-center">
            <TrendingDown size={18} className="text-rose-500" />
          </div>
          <div>
            <p className="text-xs text-slate-400 font-medium">Total Expenses</p>
            <p className="text-lg font-bold text-rose-500">${totalExpense.toFixed(2)}</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="card">
        <div className="flex flex-wrap gap-3 items-center">
          {/* Search */}
          <div className="relative flex-1 min-w-48">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input type="text" className="input pl-9" placeholder="Search transactions…"
              value={search} onChange={e => setSearch(e.target.value)} />
          </div>

          {/* Type filter */}
          <div className="flex rounded-xl border border-surface-200 overflow-hidden">
            {TYPES.map(t => (
              <button key={t} onClick={() => setTypeFilter(t)}
                className={`px-4 py-2 text-sm font-medium capitalize transition-colors
                  ${typeFilter === t ? 'bg-primary-600 text-white' : 'text-slate-500 hover:bg-surface-50'}`}>
                {t}
              </button>
            ))}
          </div>

          {/* Sort */}
          <div className="relative">
            <select value={sort} onChange={e => setSort(e.target.value)}
              className="input appearance-none pr-8 cursor-pointer w-44">
              {SORTS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
            </select>
            <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="card p-0 overflow-hidden">
        {filtered.length === 0 ? (
          <div className="py-16 text-center">
            <p className="text-slate-400 text-sm">No transactions found.</p>
            <button onClick={handleAdd} className="mt-3 btn-primary">Add your first transaction</button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-surface-50 text-left border-b border-surface-100">
                  <th className="px-5 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wide">Description</th>
                  <th className="px-4 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wide">Category</th>
                  <th className="px-4 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wide">Date</th>
                  <th className="px-4 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wide">Type</th>
                  <th className="px-4 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wide text-right">Amount</th>
                  <th className="px-4 py-3 font-semibold text-slate-500 text-xs uppercase tracking-wide text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-surface-100">
                {filtered.map(t => (
                  <tr key={t.id} className="hover:bg-surface-50 transition-colors group">
                    <td className="px-5 py-3.5 font-medium text-slate-800">{t.description}</td>
                    <td className="px-4 py-3.5">
                      <span className="bg-surface-100 text-slate-600 text-xs font-medium rounded-lg px-2.5 py-1">
                        {t.category}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-slate-500">{format(parseISO(t.date), 'MMM d, yyyy')}</td>
                    <td className="px-4 py-3.5">
                      <span className={t.type === 'income' ? 'badge-income' : 'badge-expense'}>
                        {t.type === 'income' ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
                        {t.type}
                      </span>
                    </td>
                    <td className={`px-4 py-3.5 text-right font-bold ${t.type === 'income' ? 'text-green-600' : 'text-rose-500'}`}>
                      {t.type === 'income' ? '+' : '-'}${t.amount.toFixed(2)}
                    </td>
                    <td className="px-4 py-3.5 text-right">
                      <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => handleEdit(t)}
                          className="p-1.5 rounded-lg hover:bg-primary-50 text-slate-400 hover:text-primary-600 transition-colors">
                          <Pencil size={14} />
                        </button>
                        <button onClick={() => setDeleteId(t.id)}
                          className="p-1.5 rounded-lg hover:bg-rose-50 text-slate-400 hover:text-rose-500 transition-colors">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Delete confirm dialog */}
      {deleteId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setDeleteId(null)} />
          <div className="relative bg-white rounded-2xl shadow-xl p-6 w-full max-w-sm border border-surface-200">
            <h3 className="font-bold text-slate-900 mb-2">Delete Transaction?</h3>
            <p className="text-sm text-slate-500 mb-5">This action cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteId(null)} className="btn-secondary flex-1">Cancel</button>
              <button onClick={() => confirmDelete(deleteId)}
                className="flex-1 bg-rose-500 hover:bg-rose-600 text-white font-semibold text-sm px-5 py-2.5 rounded-xl transition-colors">
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      <TransactionModal open={modalOpen} onClose={() => { setModalOpen(false); setEditing(null) }} editing={editing} />
    </div>
  )
}
