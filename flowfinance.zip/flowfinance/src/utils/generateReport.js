import jsPDF from 'jspdf'
import autoTable from 'jspdf-autotable'
import { format, parseISO } from 'date-fns'

const GREEN  = [22, 163, 74]
const RED    = [244, 63, 94]
const DARK   = [15, 23, 42]
const GRAY   = [100, 116, 139]
const LIGHT  = [241, 245, 249]
const WHITE  = [255, 255, 255]
const ACCENT = [16, 185, 129]

export function generateFinancialReport(transactions, user) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' })
  const W = doc.internal.pageSize.getWidth()
  const H = doc.internal.pageSize.getHeight()
  const generatedAt = format(new Date(), 'MMMM d, yyyy • h:mm a')

  // ─── Helper ───────────────────────────────────────────────────────────────
  const fmt = (n) =>
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(n)

  // ─── Computed totals ──────────────────────────────────────────────────────
  const totalIncome  = transactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0)
  const totalExpense = transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0)
  const balance      = totalIncome - totalExpense
  const savingsRate  = totalIncome > 0 ? ((balance / totalIncome) * 100).toFixed(1) : '0.0'

  // Category breakdown
  const catMap = {}
  transactions.filter(t => t.type === 'expense').forEach(t => {
    catMap[t.category] = (catMap[t.category] || 0) + t.amount
  })
  const categories = Object.entries(catMap)
    .map(([name, amount]) => ({ name, amount, pct: totalExpense > 0 ? ((amount / totalExpense) * 100).toFixed(1) : '0.0' }))
    .sort((a, b) => b.amount - a.amount)

  // Monthly breakdown (last 6 months)
  const monthlyMap = {}
  transactions.forEach(t => {
    const key = t.date.slice(0, 7)
    if (!monthlyMap[key]) monthlyMap[key] = { income: 0, expense: 0 }
    monthlyMap[key][t.type] += t.amount
  })
  const monthly = Object.entries(monthlyMap)
    .sort(([a], [b]) => a.localeCompare(b))
    .slice(-6)
    .map(([key, v]) => ({
      month: format(parseISO(key + '-01'), 'MMM yyyy'),
      income: v.income,
      expense: v.expense,
      net: v.income - v.expense,
    }))

  // ══════════════════════════════════════════════════════════════════════════
  // PAGE 1 — COVER
  // ══════════════════════════════════════════════════════════════════════════

  // Background header block
  doc.setFillColor(...DARK)
  doc.rect(0, 0, W, 80, 'F')

  // Accent bar
  doc.setFillColor(...GREEN)
  doc.rect(0, 80, W, 3, 'F')

  // Logo circle
  doc.setFillColor(...GREEN)
  doc.circle(20, 22, 7, 'F')
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(9)
  doc.setTextColor(...WHITE)
  doc.text('FF', 20, 24.5, { align: 'center' })

  // App name
  doc.setFontSize(22)
  doc.setFont('helvetica', 'bold')
  doc.setTextColor(...WHITE)
  doc.text('FlowFinance', 30, 24)

  // Report title
  doc.setFontSize(32)
  doc.setFont('helvetica', 'bold')
  doc.setTextColor(...WHITE)
  doc.text('Financial Report', 15, 52)

  doc.setFontSize(12)
  doc.setFont('helvetica', 'normal')
  doc.setTextColor(148, 163, 184)
  doc.text(`Prepared for ${user?.name || 'Account Holder'}`, 15, 62)
  doc.text(`Generated on ${generatedAt}`, 15, 70)

  // ── Summary cards ──────────────────────────────────────────────────────
  const cardY = 95
  const cardH = 38
  const cardW = (W - 40) / 3
  const cards = [
    { label: 'Total Balance',  value: fmt(balance),      color: balance >= 0 ? GREEN : RED },
    { label: 'Total Income',   value: fmt(totalIncome),  color: GREEN },
    { label: 'Total Expenses', value: fmt(totalExpense), color: RED },
  ]

  cards.forEach((card, i) => {
    const x = 15 + i * (cardW + 5)
    doc.setFillColor(...LIGHT)
    doc.roundedRect(x, cardY, cardW, cardH, 3, 3, 'F')
    doc.setDrawColor(...card.color)
    doc.setLineWidth(0.8)
    doc.roundedRect(x, cardY, cardW, cardH, 3, 3, 'S')

    doc.setFontSize(9)
    doc.setFont('helvetica', 'normal')
    doc.setTextColor(...GRAY)
    doc.text(card.label, x + cardW / 2, cardY + 11, { align: 'center' })

    doc.setFontSize(14)
    doc.setFont('helvetica', 'bold')
    doc.setTextColor(...card.color)
    doc.text(card.value, x + cardW / 2, cardY + 24, { align: 'center' })
  })

  // Savings rate badge
  doc.setFillColor(...LIGHT)
  doc.roundedRect(15, cardY + cardH + 8, W - 30, 18, 3, 3, 'F')
  doc.setFontSize(10)
  doc.setFont('helvetica', 'normal')
  doc.setTextColor(...GRAY)
  doc.text('Savings Rate', 25, cardY + cardH + 19)
  doc.setFont('helvetica', 'bold')
  doc.setTextColor(...ACCENT)
  doc.text(`${savingsRate}%  of income saved`, W - 25, cardY + cardH + 19, { align: 'right' })
  doc.setFont('helvetica', 'normal')
  doc.setTextColor(...GRAY)
  doc.text(`  •  ${transactions.length} total transactions`, W - 25, cardY + cardH + 19, { align: 'right' })

  // ── Monthly summary table ───────────────────────────────────────────────
  let curY = cardY + cardH + 36

  doc.setFontSize(13)
  doc.setFont('helvetica', 'bold')
  doc.setTextColor(...DARK)
  doc.text('Monthly Summary', 15, curY)
  curY += 6

  autoTable(doc, {
    startY: curY,
    head: [['Month', 'Income', 'Expenses', 'Net Cash Flow']],
    body: monthly.map(m => [
      m.month,
      fmt(m.income),
      fmt(m.expense),
      (m.net >= 0 ? '+' : '') + fmt(m.net),
    ]),
    styles: { fontSize: 9, cellPadding: 4, font: 'helvetica' },
    headStyles: { fillColor: DARK, textColor: WHITE, fontStyle: 'bold', halign: 'center' },
    columnStyles: {
      0: { halign: 'left' },
      1: { halign: 'right', textColor: GREEN },
      2: { halign: 'right', textColor: RED },
      3: {
        halign: 'right',
        fontStyle: 'bold',
      },
    },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    margin: { left: 15, right: 15 },
    didParseCell: (data) => {
      if (data.column.index === 3 && data.section === 'body') {
        const val = parseFloat(data.cell.raw.replace(/[^0-9.-]/g, ''))
        data.cell.styles.textColor = val >= 0 ? GREEN : RED
      }
    },
  })

  curY = doc.lastAutoTable.finalY + 10

  // ── Category breakdown ──────────────────────────────────────────────────
  if (categories.length > 0) {
    doc.setFontSize(13)
    doc.setFont('helvetica', 'bold')
    doc.setTextColor(...DARK)
    doc.text('Expense Breakdown by Category', 15, curY)
    curY += 6

    autoTable(doc, {
      startY: curY,
      head: [['Category', 'Amount Spent', '% of Expenses']],
      body: categories.map(c => [c.name, fmt(c.amount), `${c.pct}%`]),
      styles: { fontSize: 9, cellPadding: 4 },
      headStyles: { fillColor: DARK, textColor: WHITE, fontStyle: 'bold' },
      columnStyles: {
        0: { halign: 'left' },
        1: { halign: 'right', textColor: RED },
        2: { halign: 'right', fontStyle: 'bold' },
      },
      alternateRowStyles: { fillColor: [248, 250, 252] },
      margin: { left: 15, right: 15 },
    })

    curY = doc.lastAutoTable.finalY + 10
  }

  // ══════════════════════════════════════════════════════════════════════════
  // PAGE 2 — FULL TRANSACTION HISTORY
  // ══════════════════════════════════════════════════════════════════════════
  doc.addPage()

  // Page header
  doc.setFillColor(...DARK)
  doc.rect(0, 0, W, 20, 'F')
  doc.setFillColor(...GREEN)
  doc.rect(0, 20, W, 1.5, 'F')

  doc.setFontSize(12)
  doc.setFont('helvetica', 'bold')
  doc.setTextColor(...WHITE)
  doc.text('FlowFinance  —  Full Transaction History', 15, 13)
  doc.setFontSize(8)
  doc.setFont('helvetica', 'normal')
  doc.setTextColor(148, 163, 184)
  doc.text(generatedAt, W - 15, 13, { align: 'right' })

  const sorted = [...transactions].sort((a, b) => b.date.localeCompare(a.date))

  autoTable(doc, {
    startY: 28,
    head: [['Date', 'Description', 'Category', 'Type', 'Amount']],
    body: sorted.map(t => [
      format(parseISO(t.date), 'MMM d, yyyy'),
      t.description,
      t.category,
      t.type.charAt(0).toUpperCase() + t.type.slice(1),
      (t.type === 'income' ? '+' : '-') + fmt(t.amount),
    ]),
    styles: { fontSize: 8.5, cellPadding: 3.5 },
    headStyles: { fillColor: DARK, textColor: WHITE, fontStyle: 'bold' },
    columnStyles: {
      0: { cellWidth: 28, halign: 'left' },
      1: { cellWidth: 'auto', halign: 'left' },
      2: { cellWidth: 30, halign: 'left' },
      3: { cellWidth: 22, halign: 'center' },
      4: { cellWidth: 30, halign: 'right', fontStyle: 'bold' },
    },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    margin: { left: 15, right: 15 },
    didParseCell: (data) => {
      if (data.column.index === 4 && data.section === 'body') {
        data.cell.styles.textColor = data.cell.raw.startsWith('+') ? GREEN : RED
      }
      if (data.column.index === 3 && data.section === 'body') {
        data.cell.styles.textColor = data.cell.raw === 'Income' ? GREEN : RED
      }
    },
  })

  // ── Footer on every page ──────────────────────────────────────────────
  const pageCount = doc.internal.getNumberOfPages()
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i)
    doc.setFillColor(...LIGHT)
    doc.rect(0, H - 12, W, 12, 'F')
    doc.setFontSize(8)
    doc.setFont('helvetica', 'normal')
    doc.setTextColor(...GRAY)
    doc.text('FlowFinance — Confidential Financial Report', 15, H - 4.5)
    doc.text(`Page ${i} of ${pageCount}`, W - 15, H - 4.5, { align: 'right' })
  }

  // ── Save ──────────────────────────────────────────────────────────────
  const filename = `FlowFinance_Report_${format(new Date(), 'yyyy-MM-dd')}.pdf`
  doc.save(filename)
}
