import React, { createContext, useContext, useState, useEffect, useCallback } from 'react'
import { useAuth } from './AuthContext'

const TransactionContext = createContext(null)

const SEED_TRANSACTIONS = [
  { id: '1', type: 'income',  category: 'Salary',       description: 'Monthly salary',         amount: 5000, date: '2024-05-01' },
  { id: '2', type: 'expense', category: 'Rent',         description: 'Apartment rent',          amount: 1500, date: '2024-05-02' },
  { id: '3', type: 'expense', category: 'Groceries',    description: 'Weekly groceries',        amount: 120,  date: '2024-05-05' },
  { id: '4', type: 'income',  category: 'Freelance',    description: 'Web project payment',     amount: 800,  date: '2024-05-08' },
  { id: '5', type: 'expense', category: 'Utilities',    description: 'Electricity bill',        amount: 90,   date: '2024-05-10' },
  { id: '6', type: 'expense', category: 'Dining',       description: 'Restaurant dinner',       amount: 65,   date: '2024-05-12' },
  { id: '7', type: 'expense', category: 'Transport',    description: 'Fuel',                    amount: 55,   date: '2024-05-14' },
  { id: '8', type: 'income',  category: 'Investment',   description: 'Dividend payout',         amount: 200,  date: '2024-05-15' },
  { id: '9', type: 'expense', category: 'Shopping',     description: 'Clothing purchase',       amount: 180,  date: '2024-05-16' },
  { id:'10', type: 'expense', category: 'Health',       description: 'Doctor visit',            amount: 100,  date: '2024-05-18' },
  { id:'11', type: 'expense', category: 'Entertainment','description': 'Streaming services',    amount: 35,   date: '2024-05-20' },
  { id:'12', type: 'income',  category: 'Salary',       description: 'Bonus payment',           amount: 600,  date: '2024-05-22' },
  { id:'13', type: 'expense', category: 'Groceries',    description: 'Supermarket',             amount: 95,   date: '2024-05-25' },
  { id:'14', type: 'expense', category: 'Dining',       description: 'Lunch with colleagues',   amount: 40,   date: '2024-05-27' },
  { id:'15', type: 'expense', category: 'Subscriptions','description': 'Software subscription', amount: 29,   date: '2024-05-29' },
]

export function TransactionProvider({ children }) {
  const { user } = useAuth()
  const storageKey = user ? `ff_txns_${user.id}` : null

  const [transactions, setTransactions] = useState([])

  useEffect(() => {
    if (!storageKey) { setTransactions([]); return }
    try {
      const stored = JSON.parse(localStorage.getItem(storageKey))
      if (stored && stored.length > 0) setTransactions(stored)
      else setTransactions(SEED_TRANSACTIONS)
    } catch {
      setTransactions(SEED_TRANSACTIONS)
    }
  }, [storageKey])

  const persist = useCallback((txns) => {
    setTransactions(txns)
    if (storageKey) localStorage.setItem(storageKey, JSON.stringify(txns))
  }, [storageKey])

  const addTransaction = (txn) => {
    const newTxn = { ...txn, id: crypto.randomUUID() }
    persist([newTxn, ...transactions])
  }

  const updateTransaction = (id, updates) => {
    persist(transactions.map(t => t.id === id ? { ...t, ...updates } : t))
  }

  const deleteTransaction = (id) => {
    persist(transactions.filter(t => t.id !== id))
  }

  const totalIncome  = transactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0)
  const totalExpense = transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0)
  const balance      = totalIncome - totalExpense

  return (
    <TransactionContext.Provider value={{
      transactions, addTransaction, updateTransaction, deleteTransaction,
      totalIncome, totalExpense, balance,
    }}>
      {children}
    </TransactionContext.Provider>
  )
}

export function useTransactions() {
  return useContext(TransactionContext)
}
