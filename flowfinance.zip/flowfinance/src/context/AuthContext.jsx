import React, { createContext, useContext, useState, useEffect } from 'react'

const AuthContext = createContext(null)

const USERS_KEY = 'ff_users'
const SESSION_KEY = 'ff_session'

function getUsers() {
  try { return JSON.parse(localStorage.getItem(USERS_KEY)) || [] } catch { return [] }
}
function saveUsers(u) { localStorage.setItem(USERS_KEY, JSON.stringify(u)) }

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem(SESSION_KEY)) } catch { return null }
  })

  const register = ({ name, email, password }) => {
    const users = getUsers()
    if (users.find(u => u.email === email)) return { error: 'Email already registered.' }
    const newUser = { id: crypto.randomUUID(), name, email, password }
    saveUsers([...users, newUser])
    const session = { id: newUser.id, name: newUser.name, email: newUser.email }
    localStorage.setItem(SESSION_KEY, JSON.stringify(session))
    setUser(session)
    return { success: true }
  }

  const login = ({ email, password }) => {
    const users = getUsers()
    const found = users.find(u => u.email === email && u.password === password)
    if (!found) return { error: 'Invalid email or password.' }
    const session = { id: found.id, name: found.name, email: found.email }
    localStorage.setItem(SESSION_KEY, JSON.stringify(session))
    setUser(session)
    return { success: true }
  }

  const logout = () => {
    localStorage.removeItem(SESSION_KEY)
    setUser(null)
  }

  const forgotPassword = (email) => {
    const users = getUsers()
    const found = users.find(u => u.email === email)
    // In a real app this sends an email; here we just confirm existence
    return found ? { success: true } : { error: 'No account with that email.' }
  }

  const resetPassword = (email, newPassword) => {
    const users = getUsers()
    const idx = users.findIndex(u => u.email === email)
    if (idx === -1) return { error: 'Account not found.' }
    users[idx].password = newPassword
    saveUsers(users)
    return { success: true }
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, register, forgotPassword, resetPassword }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}
