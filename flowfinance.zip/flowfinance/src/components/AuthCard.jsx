import React from 'react'
import { TrendingUp } from 'lucide-react'

export default function AuthCard({ title, subtitle, children }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-surface-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="flex items-center justify-center gap-2.5 mb-8">
          <div className="w-10 h-10 rounded-2xl bg-primary-600 flex items-center justify-center shadow-md">
            <TrendingUp size={20} className="text-white" strokeWidth={2.5} />
          </div>
          <span className="text-xl font-bold text-slate-800 tracking-tight">FlowFinance</span>
        </div>

        <div className="card shadow-card-hover">
          <div className="mb-6">
            <h1 className="text-xl font-bold text-slate-900">{title}</h1>
            {subtitle && <p className="text-sm text-slate-500 mt-1">{subtitle}</p>}
          </div>
          {children}
        </div>
      </div>
    </div>
  )
}
