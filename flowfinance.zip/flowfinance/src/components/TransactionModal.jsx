import React, { useState, useEffect } from 'react'
import { X } from 'lucide-react'
import { useTransactions } from '../context/TransactionContext'

const CATEGORIES = {
  income:  ['Salary', 'Freelance', 'Investment', 'Business', 'Gift', 'Other'],
  expense: ['Rent', 'Groceries', 'Utilities', 'Transport', 'Dining', 'Health',
            'Shopping', 'Entertainment', 'Subscriptions', 'Education', 'Travel', 'Other'],
}

const DEFAULT = { type: 'expense', category: 'Groceries', description: '', amount: '', date: new Date().toISOString().slice(0, 10) }

export default function TransactionModal({ open, onClose, editing = null }) {
  const { addTransaction, updateTransaction } = useTransactions()
  const [form, setForm] = useState(DEFAULT)
  const [error, setError] = useState('')

  useEffect(() => {
    if (editing) setForm({ ...editing, amount: String(editing.amount) })
    else setForm({ ...DEFAULT, date: new Date().toISOString().slice(0, 10) })
  }, [editing, open])

  const handle = e => {
    const { name, value } = e.target
    setForm(f => ({
      ...f,
      [name]: value,
      ...(name === 'type' ? { category: CATEGORIES[value][0] } : {}),
    }))
  }

  const submit = e => {
    e.preventDefault()
    setError('')
    const amount = parseFloat(form.amount)
    if (isNaN(amount) || amount <= 0) { setError('Enter a valid positive amount.'); return }
    const txn = { ...form, amount }
    if (editing) updateTransaction(editing.id, txn)
    else addTransaction(txn)
    onClose()
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-md border border-surface-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-surface-100">
          <h2 className="font-bold text-slate-800">{editing ? 'Edit Transaction' : 'Add Transaction'}</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-surface-100 text-slate-400">
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={submit} className="p-6 space-y-4">
          {error && (
            <div className="text-sm text-rose-600 bg-rose-50 border border-rose-100 rounded-xl px-4 py-2.5">
              {error}
            </div>
          )}

          {/* Type toggle */}
          <div>
            <label className="label">Type</label>
            <div className="flex rounded-xl border border-surface-200 overflow-hidden">
              {['income', 'expense'].map(t => (
                <button key={t} type="button"
                  onClick={() => handle({ target: { name: 'type', value: t } })}
                  className={`flex-1 py-2.5 text-sm font-semibold capitalize transition-colors
                    ${form.type === t
                      ? t === 'income' ? 'bg-green-500 text-white' : 'bg-rose-500 text-white'
                      : 'text-slate-500 hover:bg-surface-50'
                    }`}>
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="label">Category</label>
            <select name="category" className="input" value={form.category} onChange={handle}>
              {CATEGORIES[form.type].map(c => <option key={c}>{c}</option>)}
            </select>
          </div>

          <div>
            <label className="label">Description</label>
            <input name="description" type="text" className="input" placeholder="What was this for?"
              value={form.description} onChange={handle} required />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Amount ($)</label>
              <input name="amount" type="number" step="0.01" min="0.01" className="input" placeholder="0.00"
                value={form.amount} onChange={handle} required />
            </div>
            <div>
              <label className="label">Date</label>
              <input name="date" type="date" className="input" value={form.date} onChange={handle} required />
            </div>
          </div>

          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
            <button type="submit" className="btn-primary flex-1">
              {editing ? 'Save changes' : 'Add transaction'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
