import React from 'react'

export default function StatCard({ label, amount, icon: Icon, variant = 'default', subtitle }) {
  const colors = {
    default: 'bg-white',
    income:  'bg-gradient-to-br from-green-50 to-emerald-50',
    expense: 'bg-gradient-to-br from-rose-50 to-pink-50',
    balance: 'bg-gradient-to-br from-primary-600 to-primary-700',
  }
  const textColor = variant === 'balance' ? 'text-white' : 'text-slate-800'
  const subColor  = variant === 'balance' ? 'text-primary-200' : 'text-slate-400'
  const iconBg    = {
    default: 'bg-surface-100 text-slate-600',
    income:  'bg-green-100 text-green-700',
    expense: 'bg-rose-100 text-rose-600',
    balance: 'bg-white/20 text-white',
  }

  const fmt = (n) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2 }).format(n)

  return (
    <div className={`${colors[variant]} rounded-2xl p-5 shadow-card border border-white/60`}>
      <div className="flex items-start justify-between mb-3">
        <p className={`text-sm font-medium ${variant === 'balance' ? 'text-primary-100' : 'text-slate-500'}`}>{label}</p>
        {Icon && (
          <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${iconBg[variant]}`}>
            <Icon size={17} strokeWidth={2} />
          </div>
        )}
      </div>
      <p className={`text-2xl font-bold tracking-tight ${textColor}`}>{fmt(amount)}</p>
      {subtitle && <p className={`text-xs mt-1 ${subColor}`}>{subtitle}</p>}
    </div>
  )
}
